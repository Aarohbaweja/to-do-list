import React,{Component} from 'react'

class Pagination extends Component{
    state={
        querySet:[{
            rank:1,
            name:"Aaroh"
        },
        {
            rank:2,
            name:"Aaroh"
        },
        {
            rank:3,
            name:"Aaroh"
        },
        {
            rank:4,
            name:"Aaroh"
        },
        {
            rank:5,
            name:"Aaroh"
        },
        {
            rank:6,
            name:"Aaroh"
        },
        {   rank:7,
            name:"Aaroh"

        },
        {
            rank:8,
            name:"Aaroh"
        },
        {
            rank:9,
            name:"Aaroh"
        },
        {
            rank:10,
            name:"Aaroh"
        },
        {
            rank:11,
            name:"Aaroh"
        },
        {
            rank:12,
            name:"Aaroh"
        }],
        page:1,
        rows:5,
        pages:0
    }
        changeVal=()=>
        {
           let start=(this.state.page-1)*this.state.rows;
          let  end=start+this.state.rows;
         let  pages=Math.ceil(this.state.querySet.length/this.state.rows);
           this.setState({
               pages:pages
           });
           let data=this.state.querySet.slice(start,end);
           return(
               <div>{data}</div>
           )

        };

    handleNext=(e) => {
        console.log("handling")
         let current=this.state.page;
         let max=this.state.pages;
         if(current<=max)
            {   this.setState({
                    page:current+1
                })
            }
    };
    handlePrev=(e)=>{
        let current=this.state.page;
        if(current>1)
           {   this.setState({
                   page:current-1
               })
           }
   }
    render(){
       let ds=this.state.querySet.slice(0,1);
        return(
                <>
                {/* {ds.name} */}
                {/* {this.setState({})} */}
        <h1>Display data pagination</h1>
        <p>{this.state.page} page number</p>
        <button onClick={this.handleNext}>Next</button>
        <button onClick={this.handlePrev}>Prev</button>
                </>

        )
    }
}

export default Pagination;